//const nodemailer = require('nodemailer/lib/nodemailer');  



function simuler() {

    //On recupere les info dans le document html
    nom = document.getElementById('nom ');
    prenom = document.getElementById('prenom ');
    email = document.getElementById('email ');
    date = document.getElementById('date ');
    prof = document.getElementById('prof ');


    nom = nom.value;
    prenom = prenom.value;
    email = email.value;
    date = date.value;
    prof = prof.value;

    // Ici on calcule l'age
    var today = new Date();
    var birthDate = new Date(date);
    var age = today.getFullYear() - birthDate.getFullYear();
    var m = today.getMonth() - birthDate.getMonth();
    if (m < 0 || (m === 0 && today.getDate() < birthDate.getDate())) {
        age--;
    }

   if(age<18){

    data = [nom, prenom, email, prof, age,"Désolé, vous êtes mineur. Vous ne pouvez pas souscrire de contrat","Désolé, vous êtes mineur. Vous ne pouvez pas souscrire de contrat"];

   }
   
   if(age>65){

    data = [nom, prenom, email, prof, age,"Désolé, vous êtes très âgé pour souscrire ce type de contrat.","Désolé, vous êtes très âgé pour souscrire ce type de contrat."];

   }

    if(age>18 && age<=65){
        
        var prix_mensuel = prixmensuel(age,prof);
        var prix_annuel = 12*prix_mensuel;
        data = [nom, prenom, email, prof, age, prix_mensuel+"€", prix_annuel+"€"];

    }

    console.log(data);
    afficher(data);
    console.log('ok');
}



function afficher(data) {
    document.getElementById('nom_valid ').innerText = data[0]+" ";
    document.getElementById('prenom_valid ').innerText = data[1]+" ";
    document.getElementById('prof_valid ').innerText = data[3]+" ";
    document.getElementById('date_valid ').innerText = data[4]+" ";
   // document.getElementById('email_valid ').innerText = data[2]+" ";
    document.getElementById('email_valid_send ').innerText = data[2]+" ";
    document.getElementById('mensuel_valid ').innerText = data[5]+" ";
    document.getElementById('annuel_valid ').innerText = data[6]+" ";
    document.getElementById('result').hidden = false;
    document.getElementById('resultat').hidden = true;
}

function downloadPDF() {

    nom = document.getElementById('nom ');
    prenom = document.getElementById('prenom ');
    email = document.getElementById('email ');
    date = document.getElementById('date ');
    prof = document.getElementById('prof ');


    nom = nom.value;
    prenom = prenom.value;
    email = email.value;
    date = date.value;
    prof = prof.value;

    var today = new Date();
    var birthDate = new Date(date);
    var age = today.getFullYear() - birthDate.getFullYear();
    var m = today.getMonth() - birthDate.getMonth();
    if (m < 0 || (m === 0 && today.getDate() < birthDate.getDate())) {
        age--;
    }

   if(age<18){

    data = [nom, prenom, email, prof, age,"Désolé, vous êtes mineur. Vous ne pouvez pas souscrire de contrat","Désolé, vous êtes mineur. Vous ne pouvez pas souscrire de contrat"];

   }
   
   if(age>65){

    data = [nom, prenom, email, prof, age,"Désolé, vous êtes très âgé pour souscrire ce type de contrat.","Désolé, vous êtes très âgé pour souscrire ce type de contrat."];

   }

    if(age>18 && age<=65){
        
        var prix_mensuel = prixmensuel(age,prof);
        var prix_annuel = 12*prix_mensuel;
        data = [nom, prenom, email, prof, age, prix_mensuel+"€", prix_annuel+"€"];

    }
    
    // voici le long code pour inserer le  logo dans le pdf
    var img ='data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wBDAAMCAgICAgMCAgIDAwMDBAYEBAQEBAgGBgUGCQgKCgkICQkKDA8MCgsOCwkJDRENDg8QEBEQCgwSExIQEw8QEBD/2wBDAQMDAwQDBAgEBAgQCwkLEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBD/wAARCAGGAa4DASIAAhEBAxEB/8QAHQABAAMBAQEBAQEAAAAAAAAAAAcICQYFBAMBAv/EAFkQAAEDAwIDAwYGCwsJBwUAAAEAAgMEBQYHEQgSIRMxQQk3UWF2tBQiMnGBsxUYGVZXdHWRlJXSFjY4QlJicnOCobIXIzM0NYWSk7UkQ6KxwcPEJTljg6P/xAAaAQEAAgMBAAAAAAAAAAAAAAAAAwUBAgQG/8QANBEAAgEDAgMFBwQCAwEAAAAAAAECAwQREiEFMXETFTJBUSI0gZGh0fAUYbHBI0IkMzXx/9oADAMBAAIRAxEAPwDVNERAEREAREQBERAEREAREQBERAEREAREQBERAEREAREQBERAEREAREQBERAEREAREQBERAEREAREQBERAEREAREQBERAEREAREQBERAEREAREQBERAEREAREQBERAEREAREQBERAEREAREQBERAEREAREQBERAEREAREQBERAEREAREQBERAEREAREQBERAEREAREQBERAEREAREQBERAEREAREQBERAEREAREQBERAEREAREQBERAEREAREQBERAEREAREQBERAEREAREQBERAEREAREQBERAEREAREQBERAEREAREQBERAEREAREQBERAEREAREQBERAEREAREQBERAEREAREQBERAEREAREQBERAEREAREQBERAEREAREQBERAEREAREQBERAEREAREQBERAEREAREQBERAEREB5WWZBDieLXnKamnfPFZrfUXCSJhAdI2GNzy0E9ASG7Kqf3SHB/wb339KhVkNZfNBnPs3c/dZFjqqviF1Ut5RVN8yq4jdVbeUVTfMv190hwf8G99/SoU+6Q4P8Ag3vv6VCqCoq/vK49foiu7zufX6Iv190hwf8ABvff0qFPukOD/g3vv6VCqNY/imTZXVigxmwXC6VBO3Z0lO+Uj5+UdPpU64dwJa6ZREypudJbMdheN/8A6lUHtNv6EYcQfn2UlO7vKvg3+BLTvL2r4N/gTh90hwf8G99/SoU+6Q4P+De+/pUKrzrNwgal6NWB2VXCrtt4tETmtnqKBz+aAk7AvY9oIBPTcbhQWsVL27pPTPZ9Ea1L67pPTPZ9EX6+6Q4P+De+/pUKfdIcH/Bvff0qFVY0Q4dc115ddf3J3C1UjLS1hmfXzPYHF+/K1oY1x8D3gBermPB9r3hofLNhkl0p2de2tkjagEenlHxv7lsrq9lHWuXQ2V3eyjrS26FkvukOD/g3vv6VCn3SHB/wb339KhVELnabrZap1DeLZVUNSz5UNTC6J4+drgCvkUXeNwvP6EXeVyvP6F+vukOD/g3vv6VCn3SHB/wb339KhVBUTvK49foh3nc+v0Rfr7pDg/4N77+lQp90hwf8G99/SoVQVE7yuPX6Id53Pr9EX6+6Q4P+De+/pUKfdIcH/Bvff0qFUFRO8rj1+iHedz6/RF+vukOD/g3vv6VCn3SHB/wb339KhVBUTvK49foh3nc+v0Rfr7pDg/4N77+lQqS9BeLDHdesprsWs+J3G1y0NvdcHS1M0b2uaJI2coDeu+8gP0LLpWt8nN538g9m5feqdT219XqVYwk9n+xPa39erWjCT2f7GhyIivS/CIiAIiIAiIgCIiAIiIAiIgCIiAIiIAiIgCIiAIiIAiIgCIiAIiIAiIgOO1l80Gc+zdz91kWOq2K1l80Gc+zdz91kWOqo+LeOPQouL+OPQK2Xk98MsWTZhlNwyCxUFzhoLfDHEyspmTNjkfJuHAPBAOzCN/nVTVfHybdp7LGM1vpb/rVfSUgP9VG9x+uC5LCOq4in+bHHw+Oq4in+bFw6OhobfA2moKOCmhZ0bHDGGNHzAdF+6IvTnqSvnHJmVLjGhFwtMmxqMiqIrfC0+gOEjj9AYsx1ppxtaS37U/S6CrxiklrLljtUa5tLE0ufPEWFsga0d7gNiAOp2ICzNex8bzHIxzXNOxa4bEFee4pq7bfljY85xXV22XyxsTZwg6p1umus1npjK42vJJ4rRXRb9P8AOuDYpP7Ly0/NzLU1ZXcKOj9/1O1XstfT0czLJj9dBcbjWFh7NoieHtiB7i55aBt4Ak+C1RXdwvX2Tzyzsd/CdfZPVyzsedecdx/Iqf4HkFit9zgP/dVlKyZn5nghVU439KNN8U0a+z+JafY/aK8XemifU0Fuip3iNzZNxuxo6Ehqt4ol4rMQmzTQLLrbSx89TSUYuUIA3JNO4SuA9ZY14HzrquqanSltvg67qmqlKW2+DJ5EReVPJhERAEREAREQBWt8nN538g9m5feqdVSVrfJzed/IPZuX3qnXVZe8R6nVY+8Q6mhyIi9SerCIiAIiIAiIgCIiAIiIAiIgCIiAIiIAiIgCIiAIiIAiIgCIiAIiIAiIgOO1l80Gc+zdz91kWOq2K1l80Gc+zdz91kWOqo+LeOPQouL+OPQLSPyfdrFDoRNWcuxuN9q6jf0hrIo//bKzcV4eCLiKwHF8DqtN86vlJY5rbUTVtHVVcgjhnhkPM5nMf47Xcx28QRt3Ln4dOMK+ZPGxzcNnGFfMnjYu0irA/wAoLo0zKjZRbb4+1CXsvsu2BvZnrtz9kT2nJ477c238VWRsl7tGSWmlvthuMFfb62MS09RA8OZIw9xBCv6denVyoPOD0NOvTrZUHnB9y5C+6Q6XZNXuul/wGxVtY88z55aJhe8+lx23cfnXXopHFS2aJJRUtmj4rPZLNj9Cy2WK1Uluo4vkQUsLYo2/2WgBeTqDqBjGmOLVeYZdX/BbfRgbkDmfI8/JYxvi4nuC6NUe8pHe7yyfC8caXstMjKusdt8mWoaWNG/ra13T+sKguav6ek5pciC6rfp6LmlyO3sXlD9KbneGW+54vkFspJZRG2skEUjWAn5UjWu3aPTtzKfcvz7CLRp5XZpdr5RPsMlDJK2cStcyoY5h2azr8Yu7gB3krHFfo6oqHRCB08hiadwwuPKD8yqIcUqpNTWSmp8VqxTU1k/w8tLiWt2aT0HoC/iIqsqwiIgCIiAIiIArW+Tm87+QezcvvVOqpK1vk5vO/kHs3L71TrqsveI9TqsfeIdTQ5ERepPVhERAEREAREQBERAEREAREQBERAEREAREQBERAEREAREQBERAEREAREQHHay+aDOfZu5+6yLHVbFay+aDOfZu5+6yLHVUfFvHHoUXF/HHoF9E9vr6angq6mhqIoKkEwyvic1koHQ8pI2dt6lO3BVpljepWr/Z5VSx1lBZaF9wFJIN2Tyh7WsDx4tBcXEeJA8Fo1mOnmG57jUmJZTYKWstb28rISwN7HYbAxkdWEeBGygtrCVxTc849DntuHyuabqZx6GM60B8nPfLxW4Dktkq5JH0FtuMb6TmO4jMjCXtb6t2g7ekn0r4r15N7Faq5mosOplyt9A5/MaaotzKl4b/ACRIJGfnLT9KsppPpRimjeIQYdicMnYMcZZ55iDLUzHbmkeR49ANh0AGwXVZWVajW1z2S+p12NlWo1tc9kvqdmiIrkugoz190NsOu+GjHLpUmirqOQ1Furms5jBLtsQR4tcOhHzHwUmItZwjUi4y5M1nCNSLjJbMz0s3k8NTJspbQX3I7RT2Nrt319O90kjm+hsRA6n1nZd7rLwL6ZYrpXesoxK8XmC6Y9bZrg59ZUMljqmwsL3tc0MHK4hp25dhvt0KucoG428sfjHD/eqaCXknvk0FsYQevK9/NJ+djHN/tLgqWVvRpSljyK+pZW9ClKWPIy9REXnTzgRfTbrZcrxVsoLTb6mtqZOjIaeJ0j3fM1oJK9K/YPmeLRMnyTFbta4pDsySro5ImuPoBcNt/Us4bWTOltZweIiIsGAiIgCtb5Obzv5B7Ny+9U6qkrW+Tm87+QezcvvVOuqy94j1Oqx94h1NDkRF6k9WEREAREQBERAEREAREQBERAEREAREQBERAEREAREQBERAEREAREQBERAcdrL5oM59m7n7rIsdVsVrL5oM59m7n7rIsdVR8W8cehRcX8cehL/ChqO3TPW6w3Srk5Lfc3m01xJ2DYpyGhx9TZBG4+ppWrixGjkfFI2WNxa9hDmkd4I7itU9N+IXAnaMYlm+d5bQWh9yozA41UuzpZ4D2cvKO9xDhv0HiFvwuulGVOT/AHNuFV0oypyfLcmZFXHMOPHQ7HY5G2OquOQ1Dd+VtJTGONx/pybbfmVa9SuPXVvLnPo8NipcSoCSAacCeqePXK8bN/sNB9ZXbVv6FLzz0O6rxChS889DSJFmJorxQa40mpePUFbm1zvtHdLnTUVRRV8vbtkZLI1h5ebq1w5twQR1HoWna3trqN0m4rGCS1uo3UW4rGAirfxraz6gaQ4pYzgVVHQTXiqlhnrjC2V8bWNB5WB4LQTv3kb9OmyplQcW3ERb6r4XDqbcZHb7ls8UUzP+F7CP7lFXv6dCeiSZDX4hTt59nJPJq6qc+UfukkWJ4jZ2u2bPXzzvHp5YwB/iK4rBfKLZnQGOl1Cw63XaIbB1Vb3OpptvSWEuY4/Nyhf54jM3p+LOx2Sq0dsN3ulfjnbTXO3fBx8IhjkDQ1zWgntBuNvi7n1KG4u6dxQlGm9/TzIbi7pXFCUab39PMqCi+m4W242iskt91oKmiqoTyyQVETo5GH0FrgCPpXzKhPP8jTDgh0usWI6O2zMfgET73kwfV1FU5gL2w87mxRtPeG8rQ4jxLj6Ap4yPG7Fl1lq8eyS2QV9vrY3RTQTMDmuaR/cfQR1B6hQhwMV+SV3D9bWZBBIyGkrqmntb3tIMtGCHB3XvAkdK0H0NHoU/zSGKJ8oYXFjS7lHedh3L1Vso9hFJbYPWWqj2EUltgxo1Ex6kxLP8mxWgndNTWa8Vlvhkd3vZDM9jSfWQ0Lnl9t7uVVebzX3etdzVFdVS1Mx9L3vLnf3kr4l5aWG3g8pLDbwERdMNM8//AHI1OeSYjc4cepBGZLjNAY4TzvaxvI523Pu5zR8XfvWFFvkFFy5I5lWt8nN538g9m5feqdVSVrfJzed/IPZuX3qnXTZe8R6nTY+8Q6mhyIi9SerCIiAIiIAiIgCIiAIiIAiIgCIiAIiIAiIgCIiAIiIAiIgCIiAIiIAiIgOO1l80Gc+zdz91kWOq2K1l80Gc+zdz91kWOqo+LeOPQouL+OPQKbbw37K8IGO1h6usma1tED/JZLTMlI/4nBQkp4pKYw8FNZPMNu3z5zod/ECkhaSPpBH0Kvo76ujK6hvqX7MgdERQEB2+iF0t1l1gw26XaRkdJT3qldLI87NYO0A5ifAAkH6FsIsRO5XD0a4+6nEsXo8X1GxyrvLrfE2CC400zRM+No2aJGu+U4DYc2+5267lWnDrqFHMKm2S14bdQoZhU2yWl4ltM7VqjpBfbRXubDU2+mkudBUH/uqiFjnDc/yXAFp9Tt/ALJdWt14457lqRi1bhODY/PY6G5RmCtq55g6eWE/KjaG9Ghw6HqSQSPFVSUfEK1OtUTp/Mi4jWpV6idP5hThwaZx+4rXuwxzzclJfi60T9ehdKNov/wCoYPpKg9fdYbhU2m+W660byyooquGoicO9r2PDmn84C46U3TmpryZxUpunNTXkzZbIMRxXK4BTZPjdsu0YGwbW0jJuX5uYHb6FxsXDfoTDWCuZpbYe2aeYb0+7d/6JPL/cpDo6gVdJBVBpaJo2ybHw3G+y/ZesdOEt2kz17pwnu0mflTU1NR08dJR08cEELBHHFG0NYxoGwAA6AAeC/VEW5uVO1b4BMbznK6nKMNy0Y0K+QzVVC6g7eESOO7nR7PaWbnry9R16bdy+bF/JzYBbpGy5XnV3vJb1MdNTso43fP1e78zgrdIuV2Vu5anHc5HY27lqcdyNsI4dNGNPjHLjuBW0VMWxbVVUfwiYEeIdJvsfWNlH3HpXfA+Huspwdvht0ooNvTs8yf8AtqxSqv5RSqMejVlpAdu3yOFx9YbTz/8AqQsXMY07eSisbC6jGnbzUVjYzsVrfJzed/IPZuX3qnVUla3yc3nfyD2bl96p1Q2XvEep5+x94h1NDkRF6k9WEREAREQBERAEREAREQBERAEREAREQBERAEREAREQBERAEREAREQBERAcdrL5oM59m7n7rIsdVsVrL5oM59m7n7rIsdVR8W8cehRcX8cegU/6wXKKxcNmkWD29v8AmrlHW36reB0fKZC1o38SOdwPo2aoAUg43rHcrVikWDZJjdnymx0cr56CmujH81FI/q4xSRua9rXHqW77E+CrqU1FSi/NY+pWUpqKlF7ZWPqjkbDjGS5TUuosYx653eoY3mdDQUklQ8D0lrATsvkuFtuNorJbddaCpoquA8ssFRE6ORh9DmuAIPzrp7vqtmlxpxbaC6PslqjdzR220k0lO0+BLWEF7v5zy4+tSno7LWcQ9Fd9KM6qX3G60VnqLhjt5qDz1VLLDsewfIfjPhdv3OJ28NkhTjUemL3MwpxqPRF7lfUX9c1zHFjhs5p2I9BX8UJCF2mkWlOSayZpTYZjQYyWVplnqJd+zp4W/Ke7b5wNvEkBcWre+Tku9jo85yq1Vj42XOvt0Boi7oXMje4ytHr+NGdv5vqU9tTVWrGEuTJ7WnGtWjCXJnbVfk38U/c+YqHUa7fZwM3E8tNH8Ec70dkBzgevnO3oK5nTTyfeWUGcUFx1BvlqfYrfUtqJYaR7nyVYY7cR9QOVriACe/bfbqr3L+Ag9xV++H2+U9PI9C+H2+U9PIAAAADYBf1EXadoREQBRHlPFdoPiF8lx67Z1TurKd5jnFNE+ZkTx3tc5oI3HjsTsvw4tdRLjppoferxZpHRXGvfFbKWZvfE6U/Gf84ja/b17LKhznPcXvcXOcdySdySq29vpW8lCC3Ky+v5W0lCC3NocTzLFs7s0eQYffaS7W+UlrZ6aTmAcO9pHe1w3G4IBVVfKQXOCPC8Rs3aDtp7nNU8u/XlZFy7/nkVOtN9YNRNJa2aswTJJ7eKnb4RBsHwzbdxcx24JHp71/nU3VvO9XrxDe86vBrZ6eLsYGNjEccTN9yGtHQbnvXJW4jGtQcMe0/kclfiUa1BwxiT+Rxytb5Obzv5B7Ny+9U6qkrW+Tm87+QezcvvVOuOy94j1OKx94h1NDkRF6k9WEREAREQBERAEREAREQBERAEREAREQBERAEREAREQBERAEREAREQBERAcdrL5oM59m7n7rIsdVsVrL5oM59m7n7rIsdVR8W8cehRcX8cegUw6a8LWpGpWKfu5gqrJYrE97mQVt5rfg7Jy07EsABPKDuNzsCQdt9lDysTxE3atp9ENEMbgqHx0UmPyV0sLTs2SUlgDnDxI+Nt/SKr6MYNSlPfC/vBXUYwalKe6S/vByOScK2tlhliNBibslpJztFWY/IK+F3z9n8Zg9bmgKWcBxE8I2GXvUzUmemgzW+W2W2WCwsmZJPF2m28svKSGgbNJ9AG2+52VZ8czjMsQLzi+UXO1dp8sUlS+MO+cA7Lz7tebvfq19xvdzqq+qk+VNUyukefpcd1tGrTpvVBPPXkbRq06b1wTz+72R8jnOc4ucSSTuSfEr+IvZxrDctzKpdR4njN0vEzPlsoqV8xYPS7lB2HzrnSbeEcyTbwjxl6eNZLfMPvtFkuN3KWguVvlE1PPEerHD1HoR4EHoR0K6e8aE6y2GjdcLtplkcFNG3mfL8Ake1jfS7lB2HrK4Ugg7EbELLjKD3WDZxlTe6wyweV8cuu2U4++wNuNttHbR9nPWW6mMVQ8eOzy48m/paAfQQuE0n1+1I0lyaO+2TIKupppZQ6voKqZ0kFW0n43M0no70PHxgfHbcGN16+H45XZfldnxW2x89Vd66CiiH86R4bufUN9z6gpe3qzmpankl7etOalqefI2Tx280+R2C25BSscyG50kNXG13e1sjA4A+sbr0V8dmtdNZLRQ2WjBEFBTR0sW/8hjQ0f3BfYvVrONz1qzjcIiLJkjniC0w/yvaT3vC4C1tdLG2poHuOwbUxODmfQ7YtPqcVkrdrVcbHcqmz3ejlpK2jldDPBK0tfG9p2IIK2wUe51oBpBqTc23rMcIoa6vbsDUguikeB3B5YQXfTuq+9sv1LUovDK6+sf1LUoPDMxdKdC9SdZ6upp8GsfbxUbeaoq6iQQ08ZPc0vd0Lj4NG57z3dV8mpmjmo2kNwjt2e43NbzUAmnna9ssEwHfySMJaT6t9x4ha543jGPYfaYbFi9npbZb4BtHT00YYwevYd59aj/igxG05hoXl1Jc6aOR9BbZrjSSOb8aKeFpe1zT4b8pafU4hc0+FxjSbz7S+RzT4VGNJvPtL5GTCtb5Obzv5B7Ny+9U6qkrW+Tm87+QezcvvVOq+y94j1K6x94h1NDkRF6k9WEREAREQBERAEREAREQBERAEREAREQBERAEREAREQBERAEREAREQBERAcdrL5oM59m7n7rIsdVsVrL5oM59m7n7rIsdVR8W8cehRcX8cegU98R3XTDQ9/gcTc38z2qBFOmRZ7pDqTgeA4xk15yGx1+H2p1uklp7bHUwzFxaeb/SNcAOX0eKr6WHCcc80v5K6jhwnHO7S/lEFopfoNA7VmbS3SvVnGchrdt22usc+2Vsh/kxsnAbIf6LtvWo0yTFsjw67TWLKbJWWqvp3cskFVCY3D1jfvB8CNwR1BWkqcoLLWxHKlKCy1sfXgOLuzbN7DiDZ+x+zFxgonS7b9m17w1zvXsCT9CljXrVu92HKblpLpncKnGsRxeofa46S3SugdVSxHkllnezZ0jnPa7vO3QKGMfvlyxi+2/I7PN2NdbKmKrp37bhskbg5pI8RuO5d5r/TUNZmkOeWqEw0ecUUeQNiJ37KeYkVDN/ECZsmxW8JaaT088/QkhLTSennnfp/9OYxzUzUHErky7Y7md4oaljg7mjrJNn+pzSdnD1EEKVOJanst8xbTfViC209vvuZ22qkvMNOwMjlmgfG0VAaO4v53b+nl+dQMBuQB4qdOKyiqbJcNPcYbG9tFbMJt4g6fFe+R0j5HA+PUgH+iswbdKeeW3zyZhJulPPLb55ILU+cDtkgvHENZpp4w8Wulq65oI6cwjLAfoMm/wA4CjHDdI9TNQZhHiGE3W4M32dUNgLKdn9KZ+0bfpcFYbQSwYxwuZ1Jm+rmpWM09SbdNRCzWupdcKxj3uYfjiEOazbkPeduvetrWm1UjOS9lPn5G1rTaqRnJYinz8jQdFUfJ/KLaeURfHimHXm6OHRslS5lOw+vbdx2UZ3jyjOo9Q8/YPCLDRM8PhD5Zz/cWq8lxC3j/tkvp8Rt4f7ZNBEWe2P+UV1Oprgx+TYlj9dRb/HjpGS08gHqc57xv9CvHptntp1Owm1ZxZIpYqS6Q9o2KUfHjcCQ5p8OhBG6koXdK4eIPckoXdK4eIPc6ZF81yuNDZ7fU3W51UdNSUcTp55pDs2ONo3c4+oAKsGQeUN0lttZJTWPHr7d443FonDGQMft4tDiXbfOAfUpKtenR8bwSVa9Oj/2PBahcFr5UMpdEs6nedgzH678/YuAH51A9B5RjTSZ4Fwwq/0zPFzHxSkfRuF5+uXGJo9qFohlOO4rdbhFe7nSx01PRVdC+Nz2umYJPjt5mDZnOeruu3Rc87yhKnLTJcmc9S8oSpy0yXJlCVa3yc3nfyD2bl96p1VJWt8nN538g9m5feqdUdl7xHqUNj7xDqaHIiL1J6sIiIAiIgCIiAIiIAiIgCIiAIiIAiIgCIiAIiIAiIgCIiAIiIAiIgCIiA47WXzQZz7N3P3WRY6rYrWXzQZz7N3P3WRY6qj4t449Ci4v449AiIqgpz+se+N4kjcWuadwQdiD6VKtk4gb1NaYcW1Px+gzyxQjkiiuTnMrKZv/AOCrb8dn08w9SilFvGcoeFm0KkoeFkpm+8NdNKblTaf51Vy/Kbbaq/07KXf0GRkHalv5j61yOeZ3cM9ulPW1NvordSUFMyit9BRMLYKSnbvysbzEuPUklxJJJJXNIsyqOSwZlUclgKYbFxU6oWfHKLGKyDHr5TWyPsqCW8WmOqmpWDuax7vAevdQ8ixCpKn4XgQqTp+F4O5y/W/VXOWdhkOa3CSl22FJA/4PTtHoEUfK0D1bLhu9EWJSlN5k8mspSm8yeQiItTB/WguIaO8nZbCaJ4xBh2k2KY9Azl+D2qnc/wDrHsD3f+JxWPbXFrg4d4O61/0Pzm1aiaW47kdqqGSB9DFBUNadzFPGwNewjwII/MQrfhONcvXBb8Ixrl64OizLG6fMMTvGKVbyyG70M1E9w/iiRhbv/ese88wu9ad5hdcKyGHs6+0zmGUDucNg5rx6nNLXD1ELZipqaejp5KurmZDDCwvkke4NaxoG5JJ7gskOIrN6LUXWvK8utkgkoqusbFTPHc+KGNkLHfS2MH6VLxaMdMZef9E3F4x0xl5/0RwiIqMogrW+Tm87+QezcvvVOqpK1vk5vO/kHs3L71TrqsveI9TqsfeIdTQ5ERepPVhERAEREAREQBERAEREAREQBERAEREAREQBERAEREAREQBERAEREAREQHHay+aDOfZu5+6yLHVbW3yzUGR2S4Y9dYnSUV0pZaKpY1xaXRSMLHgEdRu1x6hQh9o1w5felXfrWo/bVbfWlS5knDGxWX9nUupRcMbGYKLT77Rrhy+9Ku/WtR+2n2jXDl96Vd+taj9tcHdVf1X58Dg7pr+q/PgZgotPvtGuHL70q79a1H7afaNcOX3pV361qP207qr+q/PgO6a/qvz4GYKLT77Rrhy+9Ku/WtR+2n2jXDl96Vd+taj9tO6q/qvz4Dumv6r8+BmCi0++0a4cvvSrv1rUftp9o1w5felXfrWo/bTuqv6r8+A7pr+q/PgZgotPvtGuHL70q79a1H7afaNcOX3pV361qP207qr+q/PgO6a/qvz4GYKLT77Rrhy+9Ku/WtR+2n2jXDl96Vd+taj9tO6q/qvz4Dumv6r8+BmCuuwDVvUjS2pkqsBy6utBm27WOMtfDIR3F0Tw5jj6yFoh9o1w5felXfrWo/bT7Rrhy+9Ku/WtR+2to8MuIvMWk+r+xmPC7iLzFpPq/sUFzfiG1p1FonW3L9QrlWUb/l00QjpoZP6TIWsa76QVHa0++0a4cvvSrv1rUftp9o1w5felXfrWo/bSXDbmbzKSfxf2My4ZczeZST+L+xmCi0++0a4cvvSrv1rUftp9o1w5felXfrWo/bWvdVf1X58DXumv6r8+BmCrW+Tm87+QezcvvVOrI/aNcOX3pV361qP212OmHDnpTo9e6nIcDslTRVtXSmilfJWyzAxF7XkbPcQPjMb19Snt+HVaVWM5NYX56E9tw2rRqxnJrCJMREV0XYREQBERAEREAREQBERAEREAREQBERAEREAREQBERAEREARF+FbW0dtpJq+41cNLS07DJNNNIGRxtHe5zj0AHpKA/dFFlVxR8PtHXNt82q1jdK47B0UjpYvpkY0sH513+OZTjWYW1t5xS/2+8ULyWiooalk0fMO9vM0kAjxHetI1ITeItM0jUhN4i0z1ERFubhERAEREAREQBERAEREARF8F6v8AY8boTc8ivNDa6Nrgw1FZUMhjDj3DmcQNz6FhtJZYPvRedYsjx7KKN1wxq+2+60rXmJ01FUsnYHgAlpcwkb7EdPWF6KJprKAREWQEREAREQBERAEREAREQBERAEREAREQBERAEREAREQBERAEREAREQBERAEREAWcPG/rld831Dq9M7NXyx49jU3waeGN5Dauub/pHPA+VyO+I0HuLXHxWjyyUo4mV3E7BDWNEzKjPGtlD+vOHXDZ2/z7lVnE5yUIwXmyr4pOShGmv9mSvjXk9tVL5jEN6uWR2Wz3CpiE0dtqRK58e43DZXtaQx3duAHbfOox0/zfULhZ1ekgr4qimmttUKW+WvtN46uDvI7+UnldzRv8Nwe4kHWJZqcfkEMOvz5Io2tdPZqOSQgdXO3e3c+vZrR9AXPd2kLWCq0tmmc95aQtIKrS2aZpDa7nRXq2Ud5tk7Z6OvgjqaeVvc+N7Q5rh84IK+pR1w6vfJoRgTpHlxGP0Tdz6BE0AfQAAvh1C4m9FtMrlJZMlzCN9zi37SjooX1MkZH8V/IC1jv5riD6lbdrGMFObxkt1VioKc3jJKaKL9IeIzTrWy43G1YYbm2otsLZ5W1lKIg5jncu7SHHfrt0Ox6/Ov21X4hdMdHOSmyu7yTXKRgkjttDGJqksPc4gkNYD4F7m7+G6dvT0dpqWPUz2sHHXnYkpFWO2cf2klXWinr8dyahge7YVDoIZGtHpc1snMPoDirC4rluN5xY6fJMTvNNc7bVD/NzwO3G472kHq1w8WkAjxCxSuKVbaEsiFanU8Dyeuih7MOKzSPBssrcMyGrusNfb5Ww1Dm0DnRsLmh2+++5GzgdwPm3UwNc17Q9jg5rhuCDuCFvCrCo2ovODaM4ybSfI/q+evnnpqCpqaWmNRNFC98cIOxkcGkhv0nouX1O1Vw/SOxQZDmVVPFTVNS2khbBCZZHyFrnbADwAaSSen0kL/Gl2rOI6v2eqvmHSVj6ajqTSymppzERJyh2w7wejh3FY7SGrs87+g1x1ac7lSdHOIvW3ItZrNabreZrjS3e4CmrLaaZjY4YiTzuaA3mZ2bd3d+/xPjb9VelQthPENoZledx2LF6SSO+3aR0IqjahEZy0F2zpAObbZp25v7lM8kkcUbpZXtYxgLnOcdgAO8k+C57KOmD9vXuRUFhP2sn+lXvjf8ANHbvy/T/AFFQvsy3jJ0nxu4y2y2x3S/PhcWunoImfB9x3gPe5pd87QQfAqLuInXjAtX9I6amxueqprjS3ynlmoK2MMmEfYzjnbylzXN3IG4O43G4G4UN5dUZ0ZwjJZwKlSLi0mdlwK/vCyH8rj6lisuq0cCv7wsh/K4+pYp7y/NcXwKzvvuWXiG30bDyhz9y6R22/Kxo3c93Q9ACprKSjaxb5YNqW1NHuIq91HGxphFVmGGw5JPCDsZmwQjf1hpl32+fZSnp3q1guqNJJPiV4E00ADp6SZvZ1EI9LmHvH84bjw3UtO6o1ZaYSTZupxeyZ2KIov1D4jNN9Oq99nrqupuVyiO0tLb42yGE+h7nOa0H1bkjxCkqVIUlqm8Iy2lzJQRQdjnF7pfe66OhuVPdbN2h5RPVQsdCD4czmOJHzluw8Sptp6inq6eOrpJ45oJmCSOSNwc17SNw4EdCCPFa0q9Oss03kJp8jgNctSLrpdhbMis1DSVVVLXRUjW1XMY2hzXuJIaQT8jbvHf9C+PQTVO86rY5cLrfLfRUtRRVnwcCkDwxzeRrgdnOcd+p8VEHERrbguoGHMxnHJ62Srp7nHO4y0xjYWMZI0kEnfvcPBefw660YVpnjd0teTyVrZ6uuFRH2FP2g5Oza3qdx13BVa75fq8a/Yx8MjO5bmqklhpZpoITNKyNzmRg7c7gOjfpPRVL011v1XvWqNrt1wuctbBcq5tPU0BgY1kURJDi0Abt7Mbu79/i9d+qtHimT2nM8fo8msckj6Gua50RkYWO6OLSCD3bFpC4LF9atJcgzBlosVO9l3uEjoRU/Y4RmYtBOxf8rboe9dNylUlTkqmn++X58TJKaIosy7iO07xWvktkUlXd6mElsnwFjXRscPAvc4A/2d11Va1Ois1HgylnkSmiinFeJPTrJa6O21D6yzzykNY6uY1sTnHw52uIHzu2ClUEEbhYpVqdZZpvIaa5n9REUpgIiIAiIgCIiAIiIAiIgCIiAIiIAiIgCIiALJe0/wAKKi9vo/8AqIWtCxzzSoulJq5faqxvqGXGHI6qSjdTg9q2cVTiws2683Nttt132VTxR40P9yo4q9Oh/ubGLMXjmyO05Dr/AHGO01TKgWqhprdUPYd2idnM57QfS3nDT6CCPBeLNnHF5eY3W43fU6cTAtMcUdYHOB6EfFG+ykLh44LM5yvJKLKNWLLNZcdpZRUSUVaOWruBB3EZjPxo2E/KL9iRuAOu4jr153yVKnB8yK4uJ3yVKnB8/MmzONSb1olwb4f8Bc6kyC62egtdI7ufTOkp+d8m3g5rA4D0PLfQq48NvDHc9fpLlfrtfZbVYrfN2EtSyPtZqmoI5ixm52Gwc0ucd/lN6HckT35RRjWYHiLWNDWtu0oAA2AHYldJwAeY2r9oKr6qBZnSVa7VGe8YomlTVW5VKe6ijoNP9B8F4W7LlmoFjut5uckVnlnnbXSRcvZwNdKQ0MY3q4tA67qlmmmHZDxK6yuo75eZGVF2kmuN0reXmdHE3q7kaeni1jR3N3HgNlojrj5l879m7l7s9Up4C/PdU/kGq+thS7pQValQS9n0N7inFVIUkvZ9CXNROA/AYsOrarAbpeYb5Q075oG1k7JoqpzQTyOAY3lLttg4EAHwKirgW1FuWP6pHAXzvfa8nglPYk/FjqoY3SNkHoJYx7T6d279wV/67/Uqj+qf/wCRWZvCH/CKw/8ArKz3OdLmlC3uKUqSxl/b7ivTjRrU3TWMs73jqxX7D6s0mSRR7RZBbY3vdt8qeEmNw+hgh/Orh6G5L+67SHEr86TtJJrXDFM7f5U0Q7KQ/wDGxyh/jyxX7KaaWnKoo+aWxXIMe7b5ME7eVx/42Qj6V9PAnkv2V0krMfkk3lsd1lYxu/dDK1sjT9LzL+ZSUv8ADfTj5SWfz6k1P/Hcyj6/n3I98oFkva3jE8Pjk2+DU09ymbv39o4Rxk/N2Un51N3CPiv7ltCrCZI+Se8GW6zdO/tXf5s/8psaqLxO3Gq1B4jrnZba7tXR1VLYqRvf8cBrHN/5r3rRGyWmlsNmoLHQt5aa3UsVJCPQyNga3+4BLX/Ld1Kvpt+fIUPbrzn6bGcvDZ/CAxX8fm+qkVqeMvOa/F9NafH7ZM6GbJKk0sz2nY/BmN5pGg/ziWNP80uHiqrcNn8IDFfx+b6qRT/x4/7FxD8aq/8ABGuS3k4WNRr1+xpQeKEsfnI4Xhv4aLPqnYqjMcxuNbDbm1DqWkpqRzWPmc0Aue55B2budgANyQeo26/DxKcOls0io7fk2LXGrqLRXVHwOWGrc10kExaXN2c0Dma4Nf3jccved+lgeDnzJUX4/V/415XG/wCaO3fl+n+oqFLK0pKy143xnJK6ceyzjc8zgV/eFkP5XH1LFEHE1mN3zzV+rx2Bz30tmnFqoacHp2u4Ejtu7mdJuN/Q1o8FL/Ar+8LIfyuPqWKANR66C2a+325VRcIaTJpJ5OUbnlbUcx2HzBQ15NWVOPkzL/6oosXZ+CnAY7DHT3y+3ia7PiBlqaeWNkTJNuvIwsO7QfSSTt4KuUv7oeHvWJ8NPVmWqx+saHOZ8VtXTPAds4eAfG4bjrsT37jdWjq+MnSGCnfLTsvlTI0fFiZRtaXH53PACq9WPyDiG1jkno6Hsam/1bPiN+M2lpmNazmcfEMjaNz03I7tyAl4rdKCtfFnyMz07aOZd3V/OJcL0svGXWt//aG0zG0btu6SZzWMft/N5+bb1KomgmkLNZMmuDr5cqmK3W5jZ62WJwM00kjjytDnA7b8ryXEH5Pr3FlOKGCOl0MulNCCGQyUUbQfQJ2AKOeB7vzT/d3/AMldNzFVr2nSnyx9/sSS3kkzyte+GnHsExCTNMMrK7sqGSNtbTVUgkHZvcGB7HAAghzm7g79Dv0269fwa5vXXfHLthdwmdK2yvjno3OO5bDKXczPma5u4/pn0Lv+JTzJZP8A1VP7zEoX4Jf9vZT+J03+N6w6cbe+gqawmt/r9hjTNYPy1+0FxHTfFRldiuN1lqKm5sgMNTLG6NrHtkcdtmB245QBuSvP0C0LxbVbH7ldr9c7rTS0dYKdjaOSNrS3ka7c87HHfcqWuL7zW0v5Zg+qmXmcGn7y77+VB9UxRu2pfrlT07Y5EnmTThmJ23BsYoMUtEk8lJb2OZG+dwdI7mcXEuIAG+7j3AKmGiXnmx/8ek/wPV6VRbRLzzY/+PSf4HqXiMVGpQiuSf2NkWd4hstrcS04qH22V0VTdJ2W5krTsY2va5zyPQeVjhv4b7qD9CtFrfqTDXXvIKyphttHKKZkdM4NfLLyhzt3EHYAFvcNzzd4262zuLbcaOWS7MpzSwtMshqA0xsa0blx5ugAHioWvfFBgWPSy27FrBU3GOJx2kiDaaB58S3oXfTyhSXdKj2yq3EvZ8kbRbxhEc656IW7TiipMhx2tqZrdUT/AAaWKpIc+KQtLmkOAG7SGu7xuCB1O/SY+G/LqzKNPGU1xldLUWac0Ikcdy+INa6Mk+oO5fmaFC2q2vjNTMZjx1uKm3clWyq7Y13bb8rXDl5ezb/K79/BSPwkfvTvf5Rb9U1ctrOkr3/j+Foy86dyd0RFfEYREQBERAEREAREQBERAEREAREQBERAEREAWS9p/hRUXt9H/wBRC1oWS9p/hRUXt9H/ANRCquJ86fUqeJ86fX7GtCIitS2Kj+UW/eJif5Xl+pK6PgA8xtV7QVX1UC5zyi37xMT/ACvL9SV0fAB5jar2gqvqoFVx/wDQfT7FbH359CXtcfMvnfs3cvdnqlPAX57qn8g1X1sKv5kVko8mx+543cQTS3Wjmop9u/s5WFjtvocVmPa6/OuFnWYyz0LXXGyyvhkilBbDX0rwRu0/yHt2c0+BA3G4IWt++yrU6r5I2u/YqwqPkjUKu/1Ko/qn/wDkVmbwh/wisP8A6ys9znUs6hcfE+Q4hW2LD8JntVxuNO6nfWVFYJBTNeCHGNrWjmdsehO2x67HuXncCOlFzuuaS6r3ClfFa7LFLTUEjm7CoqpGljuX0tZG54J9L2+g7aV60Lu4pqlvh5/j7GlWpG4rQVPfBbrW3Ff3a6S5VjbYu0lqbbLJA3bfeeMdpEP+NjVUngRzGnsOXZTZK+oEVLWWj7IuJPTemf1+nklef7KvastsyjuWj2rWW2a0jshBJcrXG3u3pKmKSNp+fs5WuHrAUl++wq06/pt+fUlun2c41TsOG23VGpvErR5BXxl4ZW1eRVW/XleC57D/AM58a0ZVOPJ+4ru/K83mi7hBaqd+3p/zso/uhVx1LwyGmhqfNvJvZxxTy/MzY4bP4QGK/j831Uin/jx/2LiH41Wf4I1AHDZ/CAxX8fm+qkVvuK3TO4aiab/CbHTunulgmNdDCwbumi5SJWNHi7bZwHeeTYdSq+2hKpZVIx55+xHQTlRkkfjwc+ZKi/H6v/GvK43/ADR278v0/wBRUKBNB+JS46OUFVjlxsZu9nqJzUMjbN2UtPKQA4tJBBaQ0fFO3Xrv1O/y678Ql21tdb7PR2Q2y00UpliphL20s85HKHuIAHQEgNA/jO6ncbbu9pOz7LPtYxgkdWPZafMnLgV/eFkP5XH1LFX7Uughu2vN/tdQ97YqzJZad7mEBwa+flJG/TfYq4PDPprXaZ6YU1BeITFdLrM65VkTu+Fz2tayM+sMa3ceDi5Vv4rdOrrhuo82aUUUgtl/lFVFUMB2hqgB2jCfBxI5x6Q47fJKxdUZRs6eVy5m0otU1kmWDgn0tilbJNfcmmaDuWOqYAHfORDv+Ze5Y71w4aDXOpxOhutBaLr8RtW6Vk0055gHND5eUgDYg8u4A332CjC0ccFVT4+yC8YOKu8RRBhnirBHBM8D5Zbykt9JAJ8diFFOnuL5Jr/q46subDKyrq/sheKhrSI4YObcsHo3A5GD5vAErd3FCDirSKcn+3IzqisaFuWv4qSDoneCDuDNSEH/APexRrwPd+af7u/+SpK4qfMpef6+k+vYo14Hu/NP93f/ACVLV/8ARh0+5I/GiWeJTzJZP/VU/vMShfgl/wBvZT+J03+N6mjiU8yWT/1VP7zEoX4Jf9vZT+J03+N6V/f6fT7iXjRIvF8D/ktpdgel5g3/AOVMvL4NHNOG35gcOYXNpI8QDE3b/wAj+ZSnq5g3+UTAbpjMRa2rkYJqNzjsBOw8zAT4A7FpPgHFU5021PyzQ/IbhT/YoPExEFfbqsOjPOwnlO/e1w3PXYjYnp3EaXU/017GtPwtYN+TL7qi2iXnmx/8ek/wPVtdJdR49UsRbk7bS62uFTJTPgM3agObsdw7Zu4IcPAePzqpWiXnmx/8ek/wPS/nGpUoTjyb/tGyJ94qsjrrVhlBZKOV0bLvVFtQ5p2LoowHcnzFxaf7O3iuQ4e9GcVy6wT5ZllM6uDql1PTUvaOZG0NA3e7lIJJJ2A322Hjv0kziDwKszfBy+0wuluFol+FwxNG7pWcpEjAPTtsQPEtA8VAeket9x0ugqrPU2kXK21Evbdl2vZSQy7AEtOxBBAG7SO8d4676XLhTvVK4Xs429DdZcdiQuIfTbBsSwOG6Y5jtNQ1TrjFCZY3OJLCyQkdSfED8y9LhI/ene/yi36pqijV3Wu46pspLVT2n7HW2ll7ZsPa9q+WXYtDnHYDoCQAB/GPU9NrC6A4NWYPgMUN0idFX3OY108Ths6IOaAxh9Ya0EjwLiPBLdwrXuuivZS9MB7R3JJREV4RhERAEREAREQBERAEREAREQBERAEREAREQBRzHw66JQ5M3MItObU28NrPsg2pAfuKjn5+05ebl35uvdtupGRayhGXiWTWUIz8SyERFsbHN5xpzhGpNBBbM5xylu9NSy9tCyfmHZv223BaQR0PpX74bg+JafWb9z+GWKmtNv7V05ggB2Mjtt3EkkkkADcnuAHgvdRa6I6tWNzXTHOrG4XK57pbp/qdQsoM6xekurIt+ykfzMmi37+SVhD2g+IBAPiuqRZlFSWJLKMtKSwyE7bwbcPltrRW/uMlqixweyOpuNQ+NpHhy8+zh6nbhTJb7dQWmigttroYKOkpmCOGCCMRxxsHc1rW7AD1BfQi0hShT8CSNY04Q8KwFwObaEaSai3X7OZjhdLX3Atax1S2aWCR4A2HMYnt5thsBvv0AXfItpQjNYkso2lFSWJLJ42J4fjGC2aPH8RstNa7fG4vEEDdgXHvc4ncucdh1JJ6BeyiLKSisIJJbI4axaH6TYzfYsmsODW6iucD3SRTxh28bnAgloJ5R0J7h08F3KIsRhGCxFYCio8kRvmPDvpBnNwku97xGFlfMSZKikmkp3Pce9zgwhrnesglfthWgOk2n9ey7Y5iUDa+P5FVUyvqJGH0s7QkMPraAVISLTsKWrXpWehjRHOcBfHdrPar9b5rTe7dTV1FUN5ZYKiMSMePWD0X2IpGk9mbEST8Kmhs9Uak4jIwEkmJlwqAw/Rz7j5gQpExjEcZwu2Ns+K2SltlI08xjgZtzO/lOd3uPrJJXroo4UadN5hFJ9DCilyR5uQY7ZMrtM1jyK2w19BUcpkglHxXFpBB6dQQQD0XwYlp/huCMqmYjj9NbBWlhqDFzEycu/LuSSenM7YesroUW7hFy1NbmcHwXyx2jJbVUWO+0EVbQVbQ2aCUbteAQR+YgEesLysS05wjBX1EuJY5S219WGtmdFzFzw3fYEuJ6dSukRHCLlqa3AXPZLp7hGYPE2TYtbrhMG8gmlgHahvoDx8YD6V0KJKKmsSWQeRi+J47hdqbZMYtcdBRNkdL2THOdu93eSXEknu7z4BeTatJtObHeI79acSoaavhe6SOZgduxx33IBOw7z4dF1qLHZw2WFty/YBcXk+jem+XVb7hecZhNXJ1fPA98D3n0u5CA4+sgldoiTpwqLE1lfuM4OKxjRvTfEKxlxs2NQirj6snnkfO9h9LeckNPrABXaoiQpwprEFhDOQiItwEREAREQBERAEREAREQBERAEREAREQBERAEREAREQBERAERU/4QrhX1fEFrLBVV1RNFDcKgRsklc5rB8NmHQE9OiiqVdE4wxzIalbs5xhjxFwEXM3XUnB7HmNtwC65DT02QXeLtqKhc15fMzd43BA5R/o395HyVy954mtBLBdvsJc9UbK2r5zG5sMjp2McOhD5I2uYwg/yiFs6sI82jZ1YR5yXzJORflS1VNXUsNbRVEVRT1EbZYpYnhzJGOG7XNcOhBBBBCjzMeI3RLAbw+wZXqJbaS4xODJaaNslQ+F3okETXch9TtlmU4wWZPCNpTjBZk8IkhFz+G6gYTqFb3XTCcot15po3ckjqSYPMbvAPb8ph9TgF8zdUMCdnjtMW5JTnKGx9qbbyP7QM7PtN9+Xl+QQe9NccJ55jXHCeeZ1KLxsuzDGsDsFTlGXXaK22qkLBNUytcWsL3hjdw0E9XOA7vFfRj+Q2XKbHR5Jj9eysttfEJ6aoYCGyRnucAQD+cLOpZ053M6lnTnc9FFwNu150eumLVea0moFq+wdDUCknrZXuiY2ctDhGOcAucWkEAAkrpLbmmK3bFYM4o77Siw1FOKtlwmf2MPYn+O4ycvKPn2WFOMuTNVUhLk0e0iiSTix4dorh9jXap2szb7czY5nRf8ANDOT/wASlK23K3Xiggulpr6etoqqMSwVFPK2SOVh7nNc0kEH0hYjUhPwtMRqQn4WmfSi5SPVPT2TLbpgv7qqJl8slKa24Ukhcz4NAGscZHvcAwNAkYd9/wCN865yl4mdBa6/xYzR6oWWavne2OIMe4wveTsGibl7Ikn+cjqwXNow6tNc5L5knIij3NeIHRnTy4PtGX6hWuhr4yBJStc6eaMnuD2RNc5vp6gdOqzKcYLMng2lOMFmTwSEi57DNQsH1DoZLjhGVW29QQkNlNJOHuiJG4D2/KYT6CAvuyPJ8dxC0y33Kb3RWm3wbCSprJmxRgnuG7j1J8B3lZ1JrVnYKUWtSex6aKMLFxOaCZJdW2S06n2h9Y+QRMZMXwNkee4NfI1rXE9w2J3Kk9YjOM94vIjOM94vIREWxsEREAREQBERAEREAREQBERAEREAREQBERAEREAREQBERAEREAREQBERAFTfg6/hD60/lCo9+mVyFUzhPxPKbFrzq9dL3jV1t9HX187qSoqqOSKKoaa2VwMb3AB42IPQnoQVyV03Vp9X/Bx3CbrUur/g5Hi/x6sy7ip09xShu01skvNppre6rhJD4opaqpZIW7ePI5w28d9l3+vPC7otjGgWQz43h1NQ3GwW51ZS3EOc6qc+Mhzu0eT8fmAIIPQc3QDYbfFrtimUXPjE0tyC243dau10VPRiqroKOSSngIq5yQ+RoLW7AgncjoQpt4hLfX3bRHNrba6GorKups1RHDT08TpJJHlvRrWtBJPqCgVGMnWcl+YIFRjJ1pSW+/8ABxvBxcLld+GbGg6qPwmCOupIZZPjcoZUyiP6GjlG3oaFXDSDIsX4dKy/Y7xLaN1890udxdK3Iam2R10crC0AsD5OjmFwe/mjLi4vO46KxvCNaMnxjhutVvrMfqaW805uL4qC4RvpXOkNRK6Nr+ZvMwO+L12PQ79Vyo4oNQrDQzY5rXw15M+uaDDNJaaL4XQVZ8OXm3bsfU9//osNLs6cpPDS9MrkuZhpdnSlJ4aXplclzJE0IZw7XSW85foXFZmTXTshc2UTHQvi5ebkaad+xhaSXdGta1xG/XZQvT//AHHqn8mD/pjV9fClptlkmsuW60zafz4FjN2pZKS3WWaMwucXyRu3EZALWDsi75IG7wG9AdvM4g8f1J0m4l7XxD4fhtfktrnpmR1kNJE9/K5sJgkjfyNcYwY+VzXkbc3p22KUm6MJuOMSzsvL1wJybowm44SknsvL1wSvxufwasq/rbf77Cuj4aP4PWD/AJFi/wDVQDq5kuvvE3p5drZYNJLriWNW2D7IVTa9r31t4lj2fHTwRFjSRzDm6A7lo677MdOHCpVXqfQLHKG/Y7WWastkElvNPVRvjke2JxDZOVzQRzDrt/epac1UudS5af7Jac1UunNctPp+5VXgp0MxXV+2Xi46gyVVys1irgKSzCd8UDqmWMc88hYQ4nljjAAI7jvuOit9qnZNFMW0fmx7Uako6DB6FsEQpd5Ggcjw6OOPkPaFxLe5vUjfw3UPeT8xXKMVw7K6fKMbulnlnucL4mV9HJTukaItiWh4BI38Qul429LMx1N0yoH4VRSXGrsNxFfLboxu+oi7NzCWN/jvbuCG95BdtudgYqEOytNUY5lj5kVvDsrTXGOZY+f56HIf5Q+HHKcRns9Fww5eMXmhdC28UeFRGCMFu3bMmY4vDgNiH/K36lf68nVf7pX6dZJj9XVvmorRdWOo2vO/ZCVm72j0N5m823pc4+K9uw8T2peX2iHGcK4dMlo8nfH8G566A09qoZAAOd8jmghje/kIaTsGgklc/wADWMZ1pvkeoGnuXYpXUTIZ4p47hLTyRwzvY58Z7Nzmhr2uBDmkHu9O/TEHmvCUXlbrljy5GKbTrwlF5W65Y8uRweT6c02q3HZlWFXS51VLaKqGnmukdPIWOq6aKjppOwJHg6RsZPoDdx1AXS8amgWleE6RUmVYTiNFZK+3XGnpTJShw7aB7XgtfufjHflPMd3dNt+q6HFcUymDj3yjKJ8ausdmnt3JFcX0cgpXu+B0zdmykchO7SOh7wfQux437Bfck0MmtmO2WvutYbrSPFPRUz55S0F255WAnYenZa9jF0asmt8s17GLo1ZOO+Wfdl+pd9xLhBg1JpKh5vDsTtksc7vjObU1McMYl695a6Xm6+IUecI/Dlpte9K6LUXPMdo8mveTvnqZJLk34Q2GMSvYGta7cFx5S8vI5t3bb9FMFh08hzjhnsOm2Swz0RuGH2+gqGyRFstLM2lj2JY7YhzJGg8p26t2KrzprqHrpwpW+fS3N9H7xlVko55JLVcbUJHxta9xJa17WOa5rnEuDXcr2lztwdwBLPEakJ1VmOOuGS1MRqQqVVmOnrhk/afcMOmul+oNbqFhT7vbpqyN0P2NjrP+wsY4DmHJtzOHMOYBziAdtgNgqx8SeoWL5DxVUuKaszXB+CYcyPtKCkY5xqJn07ZiS1pB+M97GE7j4jOm2+6nXQ3UHiR1MzmuyHL8Kp8SwPkIp6G40j21rncuzRE53I49fjOe9nLt0aOu45riB0q1Hw7WO18TGj1ldfKymjbFerRGC6adjY+yLmNHV4dFswhoLmlrXAO67YrRU6KdKOFnL28unoYrRU6CdGOI5y9vLp6HB6n6q8GGd4NXY3b8KmtNe2meLZWUOONppKacNPZnmZsSzm25mncEb+OxEwcDmeX7NtE2U2RTTT1OO3CS0xTTbl8lO2OOSPcnv5RJyD1MC8C8cVmp+WWo2DSvh+zKDKanaHtrrQltJQvPe5ziAHbeHPyDuJ9BsRhbcubitsGezW2TIOwBr3W6NzKcSnrswOJOwGwJ36kEgAHYbW8dVXXF528o4X8m1vHVW1xedvKOF/J7aIisCxCIiAIiIAiIgCIiAIiIAiIgCIiAIiIAiIgCIiAIiIAiIgCIiAIiIAiIgCIiAIiIAiIgCIiAIiIAiIgCIiAIiIAiIgCIiAIiIAiIgCIiAIiIAiIgCIiAIiIAiIgCIiAIiIAiIgCIiAIiIAiIgCIiAIiIAiIgCIiAIiIAiIgCIiAIiIAiIgCIiAIiIAiIgCIiAIiIAiIgCIiAIiIAiIgCIiAIiIAiIgCIiAIiIAiIgCIiAIiIAiIgCIiAIiIAiIgCIiAIiIAiIgCIiAIiIAiIgCIiAIiIAiIgCIiAIiIAiIgCIiAIiIAiIgCIiAIiIAiIgCIiA//Z';


    
    if(age<18){
        alert("Désolé vous êtes mineur pour le contrat")
    }
    else if (age>65)
    {
        alert("Désolé vous êtes très âgé pour le contrat")
    }

    //Ici on genere le pdf
    else{
        var doc = new jsPDF();
        doc.addImage(img,'jpg',0,0,40,40);
        doc.text(40, 15, "PROVIDENTIA INSURANCE : VOTRE DEVIS");
        doc.text(10, 50, "Nom : " +data[0]);
        doc.text(10, 60, "Prénom : " +data[1]);
        doc.text(10, 70, "Email : "+data[2]);
        doc.text(10, 80, "Age : " +data[4] +" ans");
        doc.text(10, 90, "Profession : " +data[3]);
        doc.text(10, 100,"Le prix mensuel pour votre contrat est de : " + data[5]);
        doc.text(10, 110,"Le montant annuel à payer  pour votre assurance est de : "+data[6]);
        doc.text(5, 130, "En cas de souscription de ce type de contrat il s’agit,en cas de décès d’une ");
        doc.text(5, 140, "couverture de 10 000€ attribuée à la famille (parents ou femme et enfant(s)) "); 
        doc.text(5, 150, "durant la période du contrat.");
        doc.save("devis.pdf");

    }

 }



 //c'est ici  que se feront les modifications sur les prix et l'age
 
function prixmensuel(age,prof){
    var  prix;

    if( prof == "ouvrier(e)"){

        if( age >= 18 && age<= 25)
        prix = 12.99

        else if(age >= 26 && age<= 45)
        {
            prix = 24.99
        }
        else if(age >= 46 && age <= 65)
        {
            prix = 34.99
        }
      

    }
     else if( prof == "profession intermédiaire"){

        if( age >= 18 && age<= 25)
             prix= 7.99

        else if(age >= 26 && age<= 45)
        {
            prix = 14.99
        }
        else if(age >= 46 && age <= 65)
        {
            prix = 24.99
        }
      

    }

    else{

        if( age >= 18 && age<= 25)
             prix = 4.99

        else if(age >= 26 && age<= 45)
        {
            prix = 9.99
        }
        else if(age >= 46 && age <= 65)
        {
            prix = 16.99
        }
      

    }

    return prix;


}

/*function sendEmail() {
    email = document.getElementById('email ');
    Email.send({
      Host: "smtp.gmail.com",
      Username: "providentia insurance",
      Password: "clemence",
      To: email,
      From: "providentiaassistance@gmail.com",
      Subject: "Sending Email using javascript",
      Body: "Well that was easy!!",
    })
      .then(function (message) {
        alert("mail sent successfully")
      });
  }

*/

